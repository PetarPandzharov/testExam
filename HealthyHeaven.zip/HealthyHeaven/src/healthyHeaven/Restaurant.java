package healthyHeaven;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {
    private String name;
    private List<Salad> menu;

    public Restaurant(String name){
        this.name = name;
        this.menu = new ArrayList<>();
    }

    public void add(Salad salad){
        menu.add(salad);
    }
    public boolean buy(String name){
        final boolean[] canBuy = {false};
        for (int i = 0; i < menu.size(); i++) {
            if (menu.get(i).getName().equals(name)){
                menu.remove(i);
                canBuy[0] = true;
            }
        }
        return canBuy[0];

    }

    public String getHealthiestSalad(){
        String healthiestSalad = "";
        int minCalories = Integer.MAX_VALUE;


        for (Salad salad : menu) {
            int calories = salad.getTotalCalories();
            if (minCalories > calories) {
                minCalories = calories;
                healthiestSalad = salad.getName();
            }

        }

        return healthiestSalad;

    }

    public String generateMenu(){
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s have %d salads:\n", this.name, this.menu.size()));
        for (Salad salad : menu) {
            sb.append(salad.getName()).append("\n");
        }

        return sb.toString().trim();
    }
}
