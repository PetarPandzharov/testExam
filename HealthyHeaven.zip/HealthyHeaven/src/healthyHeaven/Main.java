package healthyHeaven;

public class Main {
    public static void main(String[] args) {
        Vegetable carrot = new Vegetable("carr", 10);
        Vegetable pottato = new Vegetable("pott", 30);
        Vegetable tommato = new Vegetable("tom", 40);
        Vegetable cucamber = new Vegetable("cucamber", 60);

       // System.out.println(carrot.getName());
        // System.out.println(pottato.getCalories());

       // System.out.println(tommato.toString());

        Salad shopska = new Salad("Shopska");
        shopska.add(tommato);
        shopska.add(cucamber);

        Salad healthy = new Salad("healthy");
        healthy.add(carrot);
        healthy.add(cucamber);

     //   System.out.println(shopska.getProductCount());
     //   System.out.println(shopska.getTotalCalories());
     //   System.out.println(shopska.toString());

        Restaurant restaurant1 = new Restaurant("PriBobi");

        restaurant1.add(shopska);
        System.out.println(restaurant1.buy("sdfs"));
        System.out.println(restaurant1.buy("Shopska"));
        System.out.println(restaurant1.buy("Shopska"));

        restaurant1.add(shopska);
        restaurant1.add(healthy);

        System.out.println(restaurant1.getHealthiestSalad());
        System.out.println(restaurant1.generateMenu());

    }
}
